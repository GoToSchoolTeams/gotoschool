$image_dir = "../j/contents/";

