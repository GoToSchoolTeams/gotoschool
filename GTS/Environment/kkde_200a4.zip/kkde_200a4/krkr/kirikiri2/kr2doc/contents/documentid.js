// document id
var doc_id = "kr2doc";
